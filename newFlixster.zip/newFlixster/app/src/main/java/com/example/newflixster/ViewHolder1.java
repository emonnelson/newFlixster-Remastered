package com.example.newflixster;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder1 extends RecyclerView.ViewHolder {
    private TextView titleTv1,txtOverview1;


    public ViewHolder1(@NonNull View itemView) {
        super(itemView);
        titleTv1 = (TextView) itemView.findViewById(R.id.titleTv1);
        txtOverview1 = (TextView) itemView.findViewById(R.id.txtOverview1);
    }
    public TextView getTitleTv1(){
        return titleTv1;
    }

    public void setTitleTv1(TextView titleTv1){
        this.titleTv1 = titleTv1;
    }

    public  TextView getTxtOverview1() {
        return txtOverview1;
    }
    public void setTxtOverview1(TextView txtOverview1){
        this.txtOverview1 = txtOverview1;
    }

}
