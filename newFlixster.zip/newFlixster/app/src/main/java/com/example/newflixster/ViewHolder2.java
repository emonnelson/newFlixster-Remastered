package com.example.newflixster;

import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder2 extends RecyclerView.ViewHolder {
    private ImageView posterIv;

    public ViewHolder2(@NonNull View itemView) {
        super(itemView);

        posterIv = (ImageView) itemView.findViewById(R.id.posterIv1);
    }
    public ImageView getPosterIv(){
        return getPosterIv();
    }

    public void setPosterIv(ImageView posterIv){
        this.posterIv = posterIv;
    }
}
